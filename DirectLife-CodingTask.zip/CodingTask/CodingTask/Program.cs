﻿using System.Text.RegularExpressions;
class CodingTask
{
    static string names = File.ReadAllLines("names.txt")[0];
    static void Main()
    {
        int holdValue = 0;
        int letterHold;
        string[] namesList = Regex.Replace(names, "\"", "").Split(',');
        Array.Sort(namesList);
        
        for (int i = 0; i < namesList.Length; i++) 
        {
            letterHold = 0;
            foreach (char c in namesList[i])
            {
                letterHold += (int)c % 32;
            }
            holdValue += letterHold*(i+1);
        }
        Console.WriteLine(holdValue);
    }
}
//The total for this task is 871198282